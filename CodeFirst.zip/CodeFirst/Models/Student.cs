﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CodeFirst.Models
{
    public class Student
    {
        public int Id { get; set; }
        public string Ime { get; set; }
        public string Priimek { get; set; }
    }
}
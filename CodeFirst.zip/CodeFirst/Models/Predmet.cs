﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CodeFirst.Models
{
    public class Predmet
    {
        public int Id { get; set; }
        public string Ime { get; set; }
    }
}